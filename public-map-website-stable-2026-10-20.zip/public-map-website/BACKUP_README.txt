Public Map stable website backup — 2026-10-20 (Australia/Perth)

Approved release: c7232ff78f0d53fd
Stable display: https://itsangelia.github.io/public-map-project/campus-c7232ff78f0d53fd.html?mode=display&room=campus
Stable phone: https://itsangelia.github.io/public-map-project/campus-c7232ff78f0d53fd.html?room=campus

This package contains the built HTML, JavaScript, original map and character assets,
and approved wishing-tree artwork. Keep the releases directory and filenames intact.
Serve the extracted website folder with an HTTP server or HTTPS static host; opening
index.html with file:// is not a supported way to run the p5.js application.

Firebase configuration points to the existing public-map-project backend. This is a
code and asset backup; live player, wish and blessing data are not exported here.
Database rules and editable source are included in the separate source ZIP.
Restoring/deploying to another hosting URL requires adjusting the phone joining URL.
